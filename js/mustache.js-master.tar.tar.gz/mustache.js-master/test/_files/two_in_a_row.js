({
  name: "Joe",
  greeting: "Welcome"
})
