d3 = {version: "2.10.3"}; // semver
